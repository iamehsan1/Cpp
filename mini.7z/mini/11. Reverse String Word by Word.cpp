#include<iostream>
#include<cstring>
using namespace std;

int main() {
    char str[100];
    cout << "Enter string: ";
    cin.getline(str, 100);

    int len = strlen(str);
    int end = len;

    cout << "Reversed: ";

    for (int i = len - 1; i >= 0; i--) {
        if (str[i] == ' ') {
            for (int j = i + 1; j < end; j++)
                cout << str[j];
            cout << " ";
            end = i;
        } else if (i == 0) {
            for (int j = 0; j < end; j++)
                cout << str[j];
        }
    }

    return 0;
}
