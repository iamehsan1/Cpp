#include<iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter size: ";
    cin >> n;
    for(int i = 0; i < n; i++) {
        cout << string((n-i-1)*3, ' ') << "*";
        if (i != 0) cout << string(i*6 - 3, ' ') << "*";
        cout << endl;
    }
    return 0;
}
