#include<iostream>
#include<cctype>
#include<string>
using namespace std;

bool isValidPassword(string password) {
    if (password.length() < 8 || password.length() > 16)
        return false;

    if (!isalnum(password[0]) && password[0] != '_')
        return false;

    bool hasUpper = false, hasDigit = false, hasSymbol = false;
    string symbols = "@$%&*";

    for (char ch : password) {
        if (isupper(ch)) hasUpper = true;
        if (isdigit(ch)) hasDigit = true;
        if (symbols.find(ch) != string::npos) hasSymbol = true;
        if (!isalnum(ch) && symbols.find(ch) == string::npos && ch != '_')
            return false;
    }

    return hasUpper && hasDigit && hasSymbol;
}

int main() {
    string password;
    cout << "Enter password: ";
    cin >> password;

    if (isValidPassword(password))
        cout << "Valid password";
    else
        cout << "Invalid password";
    return 0;
}
