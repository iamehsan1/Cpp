#include<iostream>
#include<cctype>
using namespace std;

int main() {
    char str[100];
    cout << "Enter string: ";
    cin.getline(str, 100);

    for(int i = 0; str[i] != '\0'; i++) {
        str[i] = tolower(str[i]);
    }

    cout << "Converted String: " << str;
    return 0;
}
