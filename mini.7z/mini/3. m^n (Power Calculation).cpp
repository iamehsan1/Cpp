#include<iostream>
#include<cmath>
using namespace std;

int main() {
    int m, n;
    cout << "Enter m and n: ";
    cin >> m >> n;
    cout << "Answer is " << pow(m, n);
    return 0;
}
