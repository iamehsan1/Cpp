#include<iostream>
using namespace std;

int main() {
    int count;
    cout << "Enter how many numbers: ";
    cin >> count;

    double a[100] = {2, 4, 6};
    for (int i = 3; i < count; i++) {
        if (i == 3) a[i] = (a[0] + a[1] + a[2]) / 3;
        else a[i] = ((i-2) + (i-1) + i) / 3.0;
    }

    for (int i = 0; i < count; i++)
        cout << a[i] << ", ";
    return 0;
}
