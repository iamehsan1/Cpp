#include<iostream>
using namespace std;

int main() {
    int num, sum = 0, original, digit;
    cout << "Enter number: ";
    cin >> num;
    original = num;

    while(num > 0) {
        digit = num % 10;
        sum += digit * digit * digit;
        num /= 10;
    }

    if (sum == original)
        cout << "Yes, it is Armstrong number.";
    else
        cout << "No, it is not Armstrong number.";
    return 0;
}
