#include<iostream>
#include<vector>
using namespace std;

vector<int> multiplyArrays(int A[], int B[], int n) {
    vector<int> num1, num2;
    for(int i = 0; i < n; i++) {
        num1.push_back(A[i]);
        num2.push_back(B[i]);
    }

    int number1 = 0, number2 = 0;
    for(int i = 0; i < n; i++) {
        number1 = number1 * 10 + num1[i];
        number2 = number2 * 10 + num2[i];
    }

    int result = number1 * number2;
    vector<int> resultArray;

    while(result > 0) {
        resultArray.insert(resultArray.begin(), result % 10);
        result /= 10;
    }

    return resultArray;
}

int main() {
    int A[3], B[3];
    cout << "Enter 3 digits for Array A: ";
    for(int i = 0; i < 3; i++) cin >> A[i];
    cout << "Enter 3 digits for Array B: ";
    for(int i = 0; i < 3; i++) cin >> B[i];

    vector<int> result = multiplyArrays(A, B, 3);
    cout << "Resultant Array: ";
    for(int i : result) cout << i << " ";
    return 0;
}
